package com.ta.Controller;

import java.io.FileInputStream;
import java.util.Map;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/")
public class Controller {

	@Autowired
	ServiceImpl objservice;
	@RequestMapping(value = "load_property", method = RequestMethod.GET)

	public ResponseEntity<?> load_property(@RequestParam Map<String, String> mymap) {
		int output = 0;

		String status = "Success";

		try {
			Logger log = LogManager.getLogger("demo");

			log.debug("testAPI started: " + mymap);
			log.info("testAPI started: " + mymap);

			System.out.println(mymap.get("operation").toString());
			System.out.println(mymap.get("a").toString() + "" + mymap.get("b").toString());

			String operation = mymap.get("operation").toString();
			int a = Integer.parseInt(mymap.get("a").toString());
			int b = Integer.parseInt(mymap.get("b").toString());

			switch (operation) {
			case "add":
				output = objservice.addtion(a, b);
				break;

			case "mul":
				output = objservice.muliplication(a, b);
				break;

			case "div":
				output = objservice.division(a, b);
				break;

			case "sub":
				output = objservice.subtraction(a, b);
				break;
			}

		} catch (Exception e) {
			System.out.println(e);
			status = "failure";
		}

		mymap.put("value = ", output + "");
		mymap.put("Status", status);

		return new ResponseEntity<>(mymap, HttpStatus.OK);
	}

}