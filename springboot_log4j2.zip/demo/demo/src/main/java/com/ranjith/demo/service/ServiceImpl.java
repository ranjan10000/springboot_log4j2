package com.ranjith.demo.service;

import org.springframework.stereotype.Service;

@Service
public class ServiceImpl 
{
	
	public int addtion(int a ,int b)
	{
		int add = a+b;
		return add;
	}
	public int muliplication(int a,int b)
	{
		int mul = a*b;
		return mul;
	}
	public int division(int a,int b)
	{
		int div = a/b;
		return div;
	}
	public int subtraction(int a,int b)
	{
		int sub = a-b;
		return sub;
	}

}
